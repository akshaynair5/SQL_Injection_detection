from setuptools import setup, find_packages

setup(
    name='sql_injection_detector',
    version='1.1.0.1',
    packages=find_packages(),
    install_requires=[
        'pandas>=1.0.0',
        'scikit-learn>=0.24.0',
        'numpy>=1.18.0',
        'pymongo>=3.0',
    ],
    author='Akshay Nair',
    author_email='aks7aynair@gmail.com',
    description='A library to detect SQL injection attempts',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/akshaynair5/SQL_Injection_detector',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    extras_require = {
        "dev" : ["pytest >= 7.0", "twine >= 4.0.2"],
    },
    python_requires='>=3.6',
)
